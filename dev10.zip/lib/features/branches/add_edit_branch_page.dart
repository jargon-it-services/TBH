import 'package:action_slider/action_slider.dart';
import 'package:flutter/material.dart';

import '../../core/network/apis/branches_api.dart';
import '../../core/network/apis/services_api.dart';
import '../../core/services/DataModels/branch_detail_model.dart';
import '../../core/services/DataModels/service_model.dart';
import '../../core/services/india_states_cities_service.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_fonts.dart';
import '../../core/widgets/app_snackbar.dart';
import '../../core/widgets/app_text_field.dart';
import '../../core/widgets/jargon_dropdown.dart';
import '../../core/widgets/slide_action_button.dart';
import '../auth/registration/registration_validators.dart';
import '../auth/registration/widgets/searchable_select_field.dart';

/// Create/Edit Branch form.
///
/// Pass [existing] to edit an already-loaded branch (fields pre-filled,
/// Save calls `BranchesApi.updateBranch`); omit it to create a new one
/// (`BranchesApi.createBranch`). Reuses the same building blocks as
/// `AddFirmPage`/the registration flow throughout: [AppTextField],
/// [JargonDropdown], [SearchableSelectField] (State/City), and
/// [SlideActionButton] for Save, per the Branch module spec.
class AddEditBranchPage extends StatefulWidget {
  final BranchDetailResponse? existing;

  const AddEditBranchPage({super.key, this.existing});

  bool get isEdit => existing != null;

  @override
  State<AddEditBranchPage> createState() => _AddEditBranchPageState();
}

class _AddEditBranchPageState extends State<AddEditBranchPage> {
  static const List<String> _branchTypes = ['Male', 'Female', 'Unisex'];
  static const List<String> _statusOptions = ['Active', 'Deactive'];
  static const List<String> _weekDays = [
    'Sunday',
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
  ];
  static const String _selectBranchTypeHint = 'Select Branch Type';
  static const String _selectStatusHint = 'Select Status';
  static const String _selectWeeklyOffHint = 'Select Weekly Off Day';

  final _formKey = GlobalKey<FormState>();
  final BranchesApi _branchesApi = BranchesApi();
  final ServicesApi _servicesApi = ServicesApi();

  late String _name = widget.existing?.name ?? '';
  late String _address1 = widget.existing?.addressLine1 ?? '';
  late String _address2 = widget.existing?.addressLine2 ?? '';
  late String _pincode = widget.existing?.pincode ?? '';
  late String _latitude = widget.existing?.latitude?.toString() ?? '';
  late String _longitude = widget.existing?.longitude?.toString() ?? '';
  late String _mobile = widget.existing?.mobile ?? '';
  late String _email = widget.existing?.email ?? '';

  late String _city = widget.existing?.city ?? '';
  late String _state = widget.existing?.state ?? '';
  late String _branchType =
      widget.existing?.branchType ?? '';
  late String _status = widget.existing?.status ?? '';
  late String _weeklyOff = widget.existing?.weeklyOff ?? '';
  TimeOfDay? _openingTime;
  TimeOfDay? _closingTime;

  // ------------- State/City (bundled JSON asset) -------------
  Map<String, List<String>> _stateCityMap = {};
  List<String> _states = [];
  List<String> _cities = [];
  bool _loadingStates = false;
  String? _stateError;
  String? _cityError;

  // ------------- Services (fetched from ServicesApi) -------------
  List<ServiceModel> _catalog = [];
  Set<int> _selectedServiceIds = {};
  bool _loadingServices = true;
  bool _servicesFailed = false;

  bool _isSaving = false;

  @override
  void initState() {
    super.initState();
    if (widget.existing != null) {
      _openingTime = _parseTime(widget.existing!.openingTime);
      _closingTime = _parseTime(widget.existing!.closingTime);
      _selectedServiceIds =
          widget.existing!.services.map((s) => s.id).toSet();
    }
    _loadStatesAndCities();
    _loadServices();
  }

  TimeOfDay? _parseTime(String value) {
    final parts = value.split(':');
    if (parts.length != 2) return null;
    final hour = int.tryParse(parts[0]);
    final minute = int.tryParse(parts[1]);
    if (hour == null || minute == null) return null;
    return TimeOfDay(hour: hour, minute: minute);
  }

  String _formatTime(TimeOfDay time) =>
      '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';

  /// Loads `assets/india_states_cities.json` via the shared
  /// [IndiaStatesCitiesService] (extracted from the registration
  /// flow's identical loading logic — see that class's doc comment).
  Future<void> _loadStatesAndCities() async {
    setState(() => _loadingStates = true);
    try {
      final map = await IndiaStatesCitiesService.load();
      if (!mounted) return;
      setState(() {
        _stateCityMap = map;
        _states = map.keys.toList();
        _loadingStates = false;
        if (_state.isNotEmpty) _cities = map[_state] ?? [];
      });
    } catch (_) {
      if (!mounted) return;
      setState(() => _loadingStates = false);
    }
  }

  void _onStateSelected(String state) {
    setState(() {
      _state = state;
      _city = '';
      _cities = _stateCityMap[state] ?? [];
      _stateError = null;
    });
  }

  /// Auto-fetches the services catalog — services are never typed in
  /// manually, per the Branch module spec.
  Future<void> _loadServices() async {
    setState(() {
      _loadingServices = true;
      _servicesFailed = false;
    });

    final response = await _servicesApi.fetchServices();
    if (!mounted) return;

    if (response.isSuccess) {
      setState(() {
        _catalog = response.data ?? [];
        _loadingServices = false;
      });
    } else {
      setState(() {
        _loadingServices = false;
        _servicesFailed = true;
      });
    }
  }

  Future<void> _pickTime({required bool isOpening}) async {
    final initial =
        (isOpening ? _openingTime : _closingTime) ?? TimeOfDay.now();
    final picked = await showTimePicker(context: context, initialTime: initial);
    if (picked == null) return;
    setState(() {
      if (isOpening) {
        _openingTime = picked;
      } else {
        _closingTime = picked;
      }
    });
  }

  /// Validates the non-TextFormField selections (dropdowns, State/City,
  /// hours) that live outside the [Form] — same approach
  /// `Step1ContactInfo._validateSelections` uses for State/City.
  bool _validateSelections() {
    setState(() {
      _stateError = _state.isEmpty ? 'Please select a state' : null;
      _cityError = _city.isEmpty ? 'Please select a city' : null;
    });

    final errors = <String>[];
    if (_state.isEmpty) errors.add('state');
    if (_city.isEmpty) errors.add('city');
    if (_branchType.isEmpty) errors.add('branch type');
    if (_status.isEmpty) errors.add('status');
    if (_weeklyOff.isEmpty) errors.add('weekly off day');
    if (_openingTime == null) errors.add('opening time');
    if (_closingTime == null) errors.add('closing time');

    if (errors.isNotEmpty) {
      AppSnackbar.warning(
        context,
        'Please select: ${errors.join(', ')}',
      );
      return false;
    }

    final opening = _openingTime!.hour * 60 + _openingTime!.minute;
    final closing = _closingTime!.hour * 60 + _closingTime!.minute;
    if (closing <= opening) {
      AppSnackbar.warning(context, 'Closing time must be after opening time');
      return false;
    }

    return true;
  }

  Future<void> _save(ActionSliderController controller) async {
    if (_isSaving) return;

    if (!(_formKey.currentState?.validate() ?? false)) {
      AppSnackbar.warning(context, 'Please fix the highlighted fields');
      return;
    }
    if (!_validateSelections()) return;

    setState(() => _isSaving = true);

    final payload = {
      'name': _name.trim(),
      'address_line1': _address1.trim(),
      'address_line2': _address2.trim(),
      'city': _city,
      'state': _state,
      'pincode': _pincode.trim(),
      'latitude': double.tryParse(_latitude.trim()),
      'longitude': double.tryParse(_longitude.trim()),
      'mobile': _mobile.trim(),
      'email': _email.trim(),
      'branch_type': _branchType,
      'opening_time': _formatTime(_openingTime!),
      'closing_time': _formatTime(_closingTime!),
      'weekly_off': _weeklyOff,
      'status': _status,
      'service_ids': _selectedServiceIds.toList(),
    };

    final response = widget.isEdit
        ? await _branchesApi.updateBranch(widget.existing!.id, payload)
        : await _branchesApi.createBranch(payload);

    if (!mounted) return;
    setState(() => _isSaving = false);

    if (response.isSuccess) {
      AppSnackbar.success(
        context,
        widget.isEdit ? 'Branch updated successfully' : 'Branch created successfully',
      );
      Navigator.pop(context, true);
    } else {
      AppSnackbar.error(
        context,
        response.error ?? 'Something went wrong. Please try again.',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.pageBackground,
      appBar: AppBar(
        title: Text(
          widget.isEdit ? 'Edit Branch' : 'Add New Branch',
          style: AppTextStyles.h2.copyWith(color: Colors.white),
        ),
        backgroundColor: AppColors.primary,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.page),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _sectionTitle('Basic Information'),
              AppTextField(
                label: 'Branch Name',
                icon: Icons.storefront_outlined,
                initialValue: _name,
                onChanged: (v) => _name = v,
                validator: (v) =>
                    RegistrationValidators.required(v, 'Branch Name'),
              ),
              AppTextField(
                label: 'Address Line 1',
                icon: Icons.location_on_outlined,
                initialValue: _address1,
                onChanged: (v) => _address1 = v,
                validator: (v) =>
                    RegistrationValidators.required(v, 'Address'),
              ),
              AppTextField(
                label: 'Address Line 2 (optional)',
                icon: Icons.location_on_outlined,
                initialValue: _address2,
                onChanged: (v) => _address2 = v,
              ),
              SearchableSelectField(
                label: 'State',
                icon: Icons.map_outlined,
                value: _state.isEmpty ? null : _state,
                options: _states,
                loading: _loadingStates,
                errorText: _stateError,
                onSelected: _onStateSelected,
              ),
              SearchableSelectField(
                label: 'City',
                icon: Icons.location_city_outlined,
                value: _city.isEmpty ? null : _city,
                options: _cities,
                enabled: _state.isNotEmpty,
                disabledHint: 'Please select a State first',
                errorText: _cityError,
                onSelected: (v) => setState(() {
                  _city = v;
                  _cityError = null;
                }),
              ),
              AppTextField(
                label: 'Pin Code',
                icon: Icons.pin_drop_outlined,
                keyboardType: TextInputType.number,
                initialValue: _pincode,
                onChanged: (v) => _pincode = v,
                validator: RegistrationValidators.zip,
              ),
              const SizedBox(height: AppSpacing.verticalSmall),
              _sectionTitle('Location'),
              Row(
                children: [
                  Expanded(
                    child: AppTextField(
                      label: 'Latitude (optional)',
                      icon: Icons.explore_outlined,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true, signed: true),
                      initialValue: _latitude,
                      onChanged: (v) => _latitude = v,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AppTextField(
                      label: 'Longitude (optional)',
                      icon: Icons.explore_outlined,
                      keyboardType:
                          const TextInputType.numberWithOptions(decimal: true, signed: true),
                      initialValue: _longitude,
                      onChanged: (v) => _longitude = v,
                    ),
                  ),
                ],
              ),
              // TODO: No map/location-picker package (e.g. google_maps_flutter,
              // geolocator) exists in pubspec.yaml yet. Once one is added,
              // replace these two fields with a real "pick on map" /
              // "use current location" picker without changing the payload
              // shape above (latitude/longitude stay the same keys).
              const SizedBox(height: AppSpacing.verticalMedium),
              _sectionTitle('Contact Information'),
              AppTextField(
                label: 'Mobile Number',
                icon: Icons.phone_android_outlined,
                keyboardType: TextInputType.phone,
                initialValue: _mobile,
                onChanged: (v) => _mobile = v,
                validator: RegistrationValidators.phone,
              ),
              AppTextField(
                label: 'Email (Username)',
                icon: Icons.email_outlined,
                keyboardType: TextInputType.emailAddress,
                initialValue: _email,
                onChanged: (v) => _email = v,
                validator: RegistrationValidators.email,
              ),
              Padding(
                padding:
                    const EdgeInsets.only(bottom: AppSpacing.verticalMedium),
                child: JargonDropdown(
                  label: 'Branch Type',
                  value: _branchType.isEmpty ? _selectBranchTypeHint : _branchType,
                  icon: Icons.people_alt_outlined,
                  options: _branchTypes,
                  showCard: false,
                  showIconBackground: false,
                  onChanged: (val) => setState(() => _branchType = val),
                ),
              ),
              const SizedBox(height: AppSpacing.verticalSmall),
              _sectionTitle('Working Hours'),
              Row(
                children: [
                  Expanded(
                    child: _timeTile(
                      label: 'Opening Time',
                      icon: Icons.login_outlined,
                      time: _openingTime,
                      onTap: () => _pickTime(isOpening: true),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _timeTile(
                      label: 'Closing Time',
                      icon: Icons.logout_outlined,
                      time: _closingTime,
                      onTap: () => _pickTime(isOpening: false),
                    ),
                  ),
                ],
              ),
              Padding(
                padding:
                    const EdgeInsets.only(bottom: AppSpacing.verticalMedium),
                child: JargonDropdown(
                  label: 'Weekly Off',
                  value: _weeklyOff.isEmpty ? _selectWeeklyOffHint : _weeklyOff,
                  icon: Icons.event_busy_outlined,
                  options: _weekDays,
                  showCard: false,
                  showIconBackground: false,
                  onChanged: (val) => setState(() => _weeklyOff = val),
                ),
              ),
              const SizedBox(height: AppSpacing.verticalSmall),
              _sectionTitle('Status'),
              Padding(
                padding:
                    const EdgeInsets.only(bottom: AppSpacing.verticalMedium),
                child: JargonDropdown(
                  label: 'Status',
                  value: _status.isEmpty ? _selectStatusHint : _status,
                  icon: Icons.toggle_on_outlined,
                  options: _statusOptions,
                  showCard: false,
                  showIconBackground: false,
                  onChanged: (val) => setState(() => _status = val),
                ),
              ),
              const SizedBox(height: AppSpacing.verticalSmall),
              _sectionTitle('Services'),
              _servicesPicker(),
              const SizedBox(height: AppSpacing.verticalLarge),
              SlideActionButton(
                label: widget.isEdit ? 'Slide to Update' : 'Slide to Save',
                submitting: _isSaving,
                onSlide: _save,
              ),
              const SizedBox(height: AppSpacing.verticalMedium),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.verticalMedium),
      child: Text(
        text,
        style: AppTextStyles.h3.copyWith(
          color: AppColors.primary,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _timeTile({
    required String label,
    required IconData icon,
    required TimeOfDay? time,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.verticalMedium),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppRadius.medium),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 16),
          decoration: BoxDecoration(
            color: AppColors.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(AppRadius.medium),
          ),
          child: Row(
            children: [
              Icon(icon, size: AppIcons.defaultSize),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  time != null ? time.format(context) : label,
                  style: AppTextStyles.body.copyWith(
                    color: time != null ? AppColors.textPrimary : Colors.grey,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              const Icon(Icons.access_time_outlined,
                  color: AppColors.textSecondary),
            ],
          ),
        ),
      ),
    );
  }

  /// Service selection — auto-fetched from [ServicesApi], never typed
  /// in manually, per the Branch module spec. No pre-existing service
  /// picker exists elsewhere in the app to reuse, so this is a small,
  /// feature-local chip picker (kept private to this page rather than
  /// promoted to `core/widgets`, since nothing else uses it yet).
  Widget _servicesPicker() {
    if (_loadingServices) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 12),
        child: Center(child: CircularProgressIndicator()),
      );
    }

    if (_servicesFailed) {
      return Container(
        padding: const EdgeInsets.all(AppSpacing.page),
        decoration: BoxDecoration(
          color: AppColors.error.withOpacity(0.06),
          borderRadius: BorderRadius.circular(AppRadius.medium),
          border: Border.all(color: AppColors.error.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            const Icon(Icons.wifi_off_rounded, color: AppColors.error),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                "Couldn't load services",
                style: AppTextStyles.body.copyWith(color: AppColors.error),
              ),
            ),
            TextButton(onPressed: _loadServices, child: const Text('Retry')),
          ],
        ),
      );
    }

    if (_catalog.isEmpty) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(
          'No services available yet.',
          style: AppTextStyles.bodySmall
              .copyWith(color: AppColors.textSecondary),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: AppSpacing.verticalMedium),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: _catalog.map((service) {
          final selected = _selectedServiceIds.contains(service.id);
          return GestureDetector(
            onTap: () => setState(() {
              if (selected) {
                _selectedServiceIds.remove(service.id);
              } else {
                _selectedServiceIds.add(service.id);
              }
            }),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: selected
                    ? AppColors.primary
                    : AppColors.primary.withOpacity(0.08),
                borderRadius: BorderRadius.circular(AppRadius.medium),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (selected) ...[
                    const Icon(Icons.check, size: 14, color: Colors.white),
                    const SizedBox(width: 4),
                  ],
                  Text(
                    service.name,
                    style: AppTextStyles.bodySmall.copyWith(
                      color: selected ? Colors.white : AppColors.primary,
                      fontWeight: selected ? FontWeight.w600 : null,
                    ),
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}
