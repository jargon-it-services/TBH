import 'package:flutter/material.dart';

import '../../core/network/apis/branches_api.dart';
import '../../core/services/DataModels/branch_detail_model.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_fonts.dart';
import '../../core/widgets/card_wrapper.dart';
import '../../core/widgets/info_card.dart';
import '../../core/widgets/network_state_view.dart';
import '../../core/widgets/shimmers/branch_detail_shimmer.dart';
import '../../core/widgets/status_badge.dart';
import 'add_edit_branch_page.dart';

class BranchDetailPage extends StatefulWidget {
  final int branchId;

  const BranchDetailPage({super.key, required this.branchId});

  @override
  State<BranchDetailPage> createState() => _BranchDetailPageState();
}

class _BranchDetailPageState extends State<BranchDetailPage> {
  final BranchesApi _api = BranchesApi();

  bool _loading = true;
  String? _error;
  bool _isOffline = false;
  BranchDetailResponse? _data;

  // Tracks whether anything changed (an edit was saved) so the list
  // screen knows to silently refresh when this page is popped.
  bool _didChange = false;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    final response = await _api.fetchBranchDetail(widget.branchId);
    if (!mounted) return;

    if (response.isSuccess && response.data != null) {
      setState(() {
        _data = response.data!;
        _loading = false;
        _isOffline = false;
      });
    } else {
      setState(() {
        _loading = false;
        _error = response.error ?? "Failed to load branch details";
        _isOffline = response.isConnectivityError;
      });
    }
  }

  Future<void> _openEdit() async {
    if (_data == null) return;
    final updated = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (_) => AddEditBranchPage(existing: _data),
      ),
    );
    if (updated == true) {
      _didChange = true;
      _loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, _didChange);
        return false;
      },
      child: Scaffold(
        backgroundColor: AppColors.pageBackground,
        appBar: AppBar(
          backgroundColor: AppColors.primary,
          centerTitle: true,
          iconTheme: const IconThemeData(color: Colors.white),
          title: Text(
            'Branch Details',
            style: AppTextStyles.h2.copyWith(color: Colors.white),
          ),
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            onPressed: () => Navigator.pop(context, _didChange),
          ),
          actions: [
            if (_data != null)
              IconButton(
                icon: const Icon(Icons.edit_outlined, color: Colors.white),
                onPressed: _openEdit,
              ),
          ],
        ),
        body: _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) return const BranchDetailShimmer();

    if (_error != null) {
      return NetworkStateView(
        isOffline: _isOffline,
        message: _error,
        onRetry: _loadData,
      );
    }

    final branch = _data!;

    return RefreshIndicator(
      onRefresh: _loadData,
      color: AppColors.primary,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(AppSpacing.page),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _headerCard(branch),
            const SizedBox(height: AppSpacing.verticalLarge),
            InfoCard(
              title: "Contact Information",
              titleIcon: Icons.contact_page_outlined,
              rows: [
                InfoRowData(
                  icon: Icons.phone_iphone_outlined,
                  label: "Mobile",
                  value: branch.mobile.isEmpty ? '-' : branch.mobile,
                ),
                InfoRowData(
                  icon: Icons.email_outlined,
                  label: "Email",
                  value: branch.email.isEmpty ? '-' : branch.email,
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.verticalLarge),
            InfoCard(
              title: "Location",
              titleIcon: Icons.location_on_outlined,
              rows: [
                InfoRowData(
                  icon: Icons.home_outlined,
                  label: "Address",
                  value: branch.fullAddress.isEmpty ? '-' : branch.fullAddress,
                ),
                if (branch.latitude != null && branch.longitude != null)
                  InfoRowData(
                    icon: Icons.my_location_outlined,
                    label: "Coordinates",
                    value:
                        "${branch.latitude!.toStringAsFixed(5)}, ${branch.longitude!.toStringAsFixed(5)}",
                  ),
              ],
            ),
            const SizedBox(height: AppSpacing.verticalLarge),
            InfoCard(
              title: "Working Hours",
              titleIcon: Icons.schedule_outlined,
              rows: [
                InfoRowData(
                  icon: Icons.login_outlined,
                  label: "Opening Time",
                  value: branch.openingTime.isEmpty ? '-' : branch.openingTime,
                ),
                InfoRowData(
                  icon: Icons.logout_outlined,
                  label: "Closing Time",
                  value: branch.closingTime.isEmpty ? '-' : branch.closingTime,
                ),
                InfoRowData(
                  icon: Icons.event_busy_outlined,
                  label: "Weekly Off",
                  value: branch.weeklyOff.isEmpty ? '-' : branch.weeklyOff,
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.verticalLarge),
            _servicesCard(branch),
          ],
        ),
      ),
    );
  }

  Widget _headerCard(BranchDetailResponse branch) {
    return CardWrapper(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 52,
            width: 52,
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.12),
              borderRadius: BorderRadius.circular(AppRadius.medium),
            ),
            child: const Icon(Icons.store_mall_directory_outlined,
                color: AppColors.primary, size: 26),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(branch.name, style: AppTextStyles.h3),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  runSpacing: 6,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    if (branch.branchType.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.secondary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          branch.branchType,
                          style: AppTextStyles.bodySmall.copyWith(
                            color: AppColors.secondary,
                            fontWeight: FontWeight.w600,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    StatusBadge(status: branch.status),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _servicesCard(BranchDetailResponse branch) {
    return CardWrapper(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.design_services_outlined,
                  color: AppColors.primary),
              const SizedBox(width: AppSpacing.iconText),
              Text("Services", style: AppTextStyles.h3),
            ],
          ),
          const SizedBox(height: AppSpacing.verticalMedium),
          if (branch.services.isEmpty)
            Text(
              "No services assigned to this branch yet.",
              style: AppTextStyles.bodySmall
                  .copyWith(color: AppColors.textSecondary),
            )
          else
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: branch.services
                  .map(
                    (s) => Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(AppRadius.medium),
                      ),
                      child: Text(
                        s.name,
                        style: AppTextStyles.bodySmall
                            .copyWith(color: AppColors.primary),
                      ),
                    ),
                  )
                  .toList(),
            ),
        ],
      ),
    );
  }
}
