import '../../services/DataModels/branch_detail_model.dart';
import '../../services/DataModels/branch_model.dart';
import '../api_call_helper.dart';
import '../api_response.dart';
import '../dio_client.dart';

/// Branches API — list/detail/create/update.
///
/// Uses the shared [callApi] helper (mock/live branching +
/// `ApiResponse<T>` wrapping) exactly like `ProfileApi` /
/// `DashboardHeaderApi`, rather than `FirmsApi`'s older by-hand
/// try/catch shape — this is the current preferred pattern for new
/// API classes in this project.
///
/// [DioClient] only exposes `get`/`post` (no `put`), so create and
/// update both go through POST, matching how the rest of the app's
/// network layer is shaped today — update simply targets a
/// `/branches/{id}` path. This avoids introducing any change to the
/// shared networking layer for this feature.
class BranchesApi {
  final DioClient _client = DioClient();

  /// GET /branches
  Future<ApiResponse<List<BranchModel>>> fetchBranches() {
    return callApi<List<BranchModel>>(
      mockAsset: 'assets/mocks/branches_response.json',
      liveCall: () => _client.get('/branches'),
      parse: (data) => (data['branches'] as List)
          .map((e) => BranchModel.fromJson(e))
          .toList(),
      fallbackErrorMessage: "We couldn't load branches right now.",
    );
  }

  /// GET /branches/{branchId}/details
  Future<ApiResponse<BranchDetailResponse>> fetchBranchDetail(
    int branchId,
  ) {
    return callApi<BranchDetailResponse>(
      mockAsset: 'assets/mocks/branch_details_response.json',
      liveCall: () => _client.get('/branches/$branchId/details'),
      parse: (data) => BranchDetailResponse.fromJson(data),
      fallbackErrorMessage: "We couldn't load this branch's details.",
    );
  }

  /// POST /branches — create a new branch.
  Future<ApiResponse<bool>> createBranch(Map<String, dynamic> payload) async {
    try {
      final response = await _client.post('/branches', data: payload);

      if (response.statusCode == 200 && response.data['status'] == true) {
        return ApiResponse.success(true);
      }
      return ApiResponse.failure(
        response.data['message'] ?? 'Failed to create branch',
      );
    } catch (e) {
      return ApiResponse.failure(e);
    }
  }

  /// POST /branches/{branchId} — update an existing branch.
  Future<ApiResponse<bool>> updateBranch(
    int branchId,
    Map<String, dynamic> payload,
  ) async {
    try {
      final response = await _client.post(
        '/branches/$branchId',
        data: payload,
      );

      if (response.statusCode == 200 && response.data['status'] == true) {
        return ApiResponse.success(true);
      }
      return ApiResponse.failure(
        response.data['message'] ?? 'Failed to update branch',
      );
    } catch (e) {
      return ApiResponse.failure(e);
    }
  }
}
