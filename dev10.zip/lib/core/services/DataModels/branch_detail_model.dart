/// ================= BRANCH SERVICE (TAG) =================
///
/// A service offered at a branch, as attached to the branch itself —
/// distinct from [ServiceModel] (the full catalog a branch picks
/// from). Only carries what the Branch Details screen needs to display.
class BranchServiceItem {
  final int id;
  final String name;

  BranchServiceItem({required this.id, required this.name});

  factory BranchServiceItem.fromJson(Map<String, dynamic> json) {
    return BranchServiceItem(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
    );
  }

  Map<String, dynamic> toJson() => {'id': id, 'name': name};
}

/// ================= BRANCH DETAIL =================
///
/// Full branch record — backs both the Branch Details screen and the
/// Edit Branch form (pre-filling every field). Mirrors the
/// `FirmDetailResponse` split: [BranchModel] is the trimmed list-item
/// shape, this is the complete one, fetched per-branch via
/// `BranchesApi.fetchBranchDetail`.
class BranchDetailResponse {
  final int id;
  final String name;
  final String addressLine1;
  final String addressLine2;
  final String city;
  final String state;
  final String pincode;
  final double? latitude;
  final double? longitude;
  final String mobile;
  final String email;
  final String branchType;
  final String openingTime;
  final String closingTime;
  final String weeklyOff;
  final String status;
  final List<BranchServiceItem> services;

  bool get isActive => status.toLowerCase() == 'active';

  /// Single-line address for display, combining both address lines.
  String get fullAddress {
    final parts = [
      addressLine1,
      addressLine2,
      city,
      state,
      pincode,
    ].where((p) => p.trim().isNotEmpty);
    return parts.join(', ');
  }

  BranchDetailResponse({
    required this.id,
    required this.name,
    required this.addressLine1,
    required this.addressLine2,
    required this.city,
    required this.state,
    required this.pincode,
    this.latitude,
    this.longitude,
    required this.mobile,
    required this.email,
    required this.branchType,
    required this.openingTime,
    required this.closingTime,
    required this.weeklyOff,
    required this.status,
    required this.services,
  });

  factory BranchDetailResponse.fromJson(Map<String, dynamic> json) {
    return BranchDetailResponse(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      addressLine1: json['address_line1'] ?? '',
      addressLine2: json['address_line2'] ?? '',
      city: json['city'] ?? '',
      state: json['state'] ?? '',
      pincode: json['pincode'] ?? '',
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      mobile: json['mobile'] ?? '',
      email: json['email'] ?? '',
      branchType: json['branch_type'] ?? '',
      openingTime: json['opening_time'] ?? '',
      closingTime: json['closing_time'] ?? '',
      weeklyOff: json['weekly_off'] ?? '',
      status: json['status'] ?? '',
      services: (json['services'] as List? ?? [])
          .map((e) => BranchServiceItem.fromJson(e))
          .toList(),
    );
  }
}
